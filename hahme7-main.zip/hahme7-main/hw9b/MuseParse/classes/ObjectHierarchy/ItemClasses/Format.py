class Format():

    """
    Stub class. This may or may not be used properly later but will house any info relating to how the page should
    be set up, such as measure spacing etc.
    """

    def __init__(self):
        self.spacing = None
